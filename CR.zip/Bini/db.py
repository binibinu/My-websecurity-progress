from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base


db = SQLAlchemy() 
def get_db_connection():
    conn = SQLAlchemy.connect("database.db")
    conn.row_factory = SQLAlchemy.Row
    return conn


from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class suggestion (db.Model):
    __tablename__= "sug"
    id = db.Column(db.Integer, primary_key=True) 
    suggest = db.Column(db.String(1024),nullable=False)
    category = db.Column(db.String(100), nullable=False)


    
class User(db.Model):
    __tablename__ = "users" 
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    
    gmail = db.Column(db.String(120),unique=True, nullable=False)
    password = db.Column(db.String(100))
    
