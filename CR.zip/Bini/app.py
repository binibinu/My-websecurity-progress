from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.exc import IntegrityError
from Crypto.Cipher import AES
import base64
from werkzeug.security import generate_password_hash, check_password_hash
from db import db, User, suggestion


def pad_text(text):
    padding = 16 - len(text) % 16
    return text + chr(padding) * padding


def unpad_text(padded_text):
    padding = ord(padded_text[-1])
    return padded_text[:-padding]


AES_KEY = b'mysecretkey12345'


def encrypt(text):
    cipher = AES.new(AES_KEY, AES.MODE_ECB)
    encrypted = cipher.encrypt(pad_text(text).encode())
    return base64.b64encode(encrypted).decode()


def decrypt(enc_text):
    cipher = AES.new(AES_KEY, AES.MODE_ECB)
    decrypted = cipher.decrypt(base64.b64decode(enc_text))
    return unpad_text(decrypted.decode())


admin = {
    "biniam": "1234567",
    "abenezer": "654321"
}

app = Flask(__name__)
app.secret_key = "supersecretkey"

app.config["SQLALCHEMY_DATABASE_URI"] = 'sqlite:///database.db'
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db.init_app(app)
with app.app_context():
    db.create_all()


@app.route("/")
def home():
    return render_template('index.html')


@app.route("/register", methods=['POST', 'GET'])
def register():
    if request.method == 'POST':
        name = request.form.get('name')
        gmail = request.form.get('gmail')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')

        if len(password) < 6:
            flash("Password must be at least 6 characters long.", "danger")
            return redirect(url_for('register'))

        if password != confirm_password:
            flash("Passwords do not match.", "danger")
            return redirect(url_for('register'))

        existing_user = User.query.filter_by(gmail=gmail).first()
        if existing_user:
            flash("This email is already registered.", "danger")
            return redirect(url_for('register'))

        hashed_password = generate_password_hash(password)
        new_user = User(name=name, gmail=gmail, password=hashed_password)
        db.session.add(new_user)
        db.session.commit()

        flash("Registered successfully! You can now log in.", "success")
        return redirect(url_for('register'))

    return render_template('register.html')


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        name = request.form.get("name")
        password = request.form.get("password")

        if name in admin and admin[name] == password:
            return redirect(url_for("adminpanal"))

        user = User.query.filter_by(name=name).first()
        if user and check_password_hash(user.password, password):
            session["user"] = user.name
            flash("Welcome to the suggestion system.", "success")
            return redirect(url_for("dashboard"))
        else:
            flash("Incorrect username or password.", "danger")
            return redirect(url_for("login"))

    return render_template("login.html")


@app.route("/dashboard", methods=["POST", "GET"])
def dashboard():
    if not session.get("user"):
        return redirect(url_for("login"))

    if request.method == "POST":
        suggest = request.form.get('suggest')
        category = request.form.get('category')

        encrypted_suggest = encrypt(suggest)
        new_suggest = suggestion(suggest=encrypted_suggest, category=category)

        db.session.add(new_suggest)
        db.session.commit()

        flash("Suggestion submitted successfully!", "success")
        return redirect(url_for('dashboard'))

    return render_template('dashboard.html')


@app.route("/adminpanal")
def adminpanal():
    users = User.query.all()
    sug = suggestion.query.all()
    for s in sug:
        s.suggest = decrypt(s.suggest)

    return render_template("adminpanal.html", users=users, sug=sug)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


if __name__ == "__main__":
    app.run(debug=True)
